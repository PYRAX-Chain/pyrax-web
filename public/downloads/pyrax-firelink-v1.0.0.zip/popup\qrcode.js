/**
 * QR Code Generator for PYRAX Wallet
 * Lightweight implementation based on QR code specification
 */

const QRCode = (function() {
  // Error correction levels
  const ECL = { L: 1, M: 0, Q: 3, H: 2 };
  
  // Mode indicators
  const MODE = { Numeric: 1, Alphanumeric: 2, Byte: 4, Kanji: 8 };
  
  // Alphanumeric character set
  const ALPHANUM = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:';
  
  // Error correction codewords and block information
  const EC_CODEWORDS = [
    // Version 1-10 (we'll use version 2-4 typically for addresses)
    [[7,1,19,0,0],[10,1,16,0,0],[13,1,13,0,0],[17,1,9,0,0]],
    [[10,1,34,0,0],[16,1,28,0,0],[22,1,22,0,0],[28,1,16,0,0]],
    [[15,1,55,0,0],[26,1,44,0,0],[18,2,17,0,0],[22,2,13,0,0]],
    [[20,1,80,0,0],[18,2,32,0,0],[26,2,24,0,0],[16,4,9,0,0]],
    [[26,1,108,0,0],[24,2,43,0,0],[18,2,15,2,16],[22,2,11,2,12]],
    [[18,2,68,0,0],[16,4,27,0,0],[24,4,19,0,0],[28,4,15,0,0]],
    [[20,2,78,0,0],[18,4,31,0,0],[18,2,14,4,15],[26,4,13,1,14]],
    [[24,2,97,0,0],[22,2,38,2,39],[22,4,18,2,19],[26,4,14,2,15]],
    [[30,2,116,0,0],[22,3,36,2,37],[20,4,16,4,17],[24,4,12,4,13]],
    [[18,2,68,2,69],[26,4,43,1,44],[24,6,19,2,20],[28,6,15,2,16]],
  ];
  
  // Generate QR code as SVG
  function generateSVG(text, options = {}) {
    const {
      size = 200,
      margin = 4,
      dark = '#000000',
      light = '#ffffff',
      ecl = 'M'
    } = options;
    
    const matrix = generate(text, ECL[ecl] || ECL.M);
    const moduleCount = matrix.length;
    const moduleSize = size / (moduleCount + margin * 2);
    
    let svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" width="${size}" height="${size}">`;
    svg += `<rect fill="${light}" width="${size}" height="${size}"/>`;
    
    for (let row = 0; row < moduleCount; row++) {
      for (let col = 0; col < moduleCount; col++) {
        if (matrix[row][col]) {
          const x = (col + margin) * moduleSize;
          const y = (row + margin) * moduleSize;
          svg += `<rect fill="${dark}" x="${x}" y="${y}" width="${moduleSize}" height="${moduleSize}"/>`;
        }
      }
    }
    
    svg += '</svg>';
    return svg;
  }
  
  // Main generation function
  function generate(text, ecl) {
    // Determine best version (1-10 for our use case)
    const version = getBestVersion(text, ecl);
    const size = version * 4 + 17;
    
    // Create matrix
    const matrix = createMatrix(size);
    const reserved = createMatrix(size);
    
    // Add function patterns
    addFinderPatterns(matrix, reserved, size);
    addAlignmentPatterns(matrix, reserved, version);
    addTimingPatterns(matrix, reserved, size);
    addDarkModule(matrix, reserved, version);
    reserveFormatArea(reserved, size);
    if (version >= 7) reserveVersionArea(reserved, size);
    
    // Encode data
    const data = encodeData(text, version, ecl);
    
    // Place data
    placeData(matrix, reserved, data, size);
    
    // Apply best mask
    const masked = applyBestMask(matrix, reserved, size, ecl);
    
    return masked;
  }
  
  function createMatrix(size) {
    return Array(size).fill(null).map(() => Array(size).fill(false));
  }
  
  function getBestVersion(text, ecl) {
    const byteLength = new TextEncoder().encode(text).length;
    // Simple version selection based on byte capacity
    const capacities = [17, 32, 53, 78, 106, 134, 154, 192, 230, 271];
    for (let v = 0; v < capacities.length; v++) {
      if (byteLength <= capacities[v]) return v + 1;
    }
    return 10; // Max we support
  }
  
  function addFinderPatterns(matrix, reserved, size) {
    const positions = [[0, 0], [size - 7, 0], [0, size - 7]];
    positions.forEach(([row, col]) => {
      for (let r = 0; r < 7; r++) {
        for (let c = 0; c < 7; c++) {
          const isOuter = r === 0 || r === 6 || c === 0 || c === 6;
          const isInner = r >= 2 && r <= 4 && c >= 2 && c <= 4;
          matrix[row + r][col + c] = isOuter || isInner;
          reserved[row + r][col + c] = true;
        }
      }
      // Separator
      for (let i = 0; i < 8; i++) {
        if (row === 0 && col + i < size) { reserved[7][col + i] = true; reserved[row + i < size ? row + i : size - 1][col === 0 ? 7 : size - 8] = true; }
      }
    });
    // Separators
    for (let i = 0; i < 8; i++) {
      if (i < size) {
        reserved[7][i] = true;
        reserved[i][7] = true;
        reserved[7][size - 8 + i] = true;
        reserved[i][size - 8] = true;
        reserved[size - 8][i] = true;
        reserved[size - 1 - i][7] = true;
      }
    }
  }
  
  function addAlignmentPatterns(matrix, reserved, version) {
    if (version < 2) return;
    const positions = getAlignmentPositions(version);
    positions.forEach(row => {
      positions.forEach(col => {
        if (reserved[row] && reserved[row][col]) return;
        for (let r = -2; r <= 2; r++) {
          for (let c = -2; c <= 2; c++) {
            if (row + r >= 0 && col + c >= 0 && row + r < matrix.length && col + c < matrix.length) {
              const isOuter = Math.abs(r) === 2 || Math.abs(c) === 2;
              const isCenter = r === 0 && c === 0;
              matrix[row + r][col + c] = isOuter || isCenter;
              reserved[row + r][col + c] = true;
            }
          }
        }
      });
    });
  }
  
  function getAlignmentPositions(version) {
    if (version === 1) return [];
    const intervals = [0, 0, 18, 22, 26, 30, 34, 22, 24, 26, 28];
    const positions = [6];
    const size = version * 4 + 17;
    let pos = size - 7;
    while (pos > 6) {
      positions.unshift(pos);
      pos -= intervals[version] || 28;
    }
    return positions;
  }
  
  function addTimingPatterns(matrix, reserved, size) {
    for (let i = 8; i < size - 8; i++) {
      matrix[6][i] = i % 2 === 0;
      matrix[i][6] = i % 2 === 0;
      reserved[6][i] = true;
      reserved[i][6] = true;
    }
  }
  
  function addDarkModule(matrix, reserved, version) {
    matrix[version * 4 + 9][8] = true;
    reserved[version * 4 + 9][8] = true;
  }
  
  function reserveFormatArea(reserved, size) {
    for (let i = 0; i < 9; i++) {
      reserved[8][i] = true;
      reserved[i][8] = true;
    }
    for (let i = 0; i < 8; i++) {
      reserved[8][size - 8 + i] = true;
      reserved[size - 8 + i][8] = true;
    }
  }
  
  function reserveVersionArea(reserved, size) {
    for (let i = 0; i < 6; i++) {
      for (let j = 0; j < 3; j++) {
        reserved[i][size - 11 + j] = true;
        reserved[size - 11 + j][i] = true;
      }
    }
  }
  
  function encodeData(text, version, ecl) {
    const bytes = new TextEncoder().encode(text);
    const bits = [];
    
    // Mode indicator (byte mode = 0100)
    bits.push(0, 1, 0, 0);
    
    // Character count (8 or 16 bits depending on version)
    const countBits = version < 10 ? 8 : 16;
    for (let i = countBits - 1; i >= 0; i--) {
      bits.push((bytes.length >> i) & 1);
    }
    
    // Data bytes
    bytes.forEach(byte => {
      for (let i = 7; i >= 0; i--) {
        bits.push((byte >> i) & 1);
      }
    });
    
    // Terminator
    const capacity = getDataCapacity(version, ecl);
    while (bits.length < capacity * 8 && bits.length < capacity * 8) {
      bits.push(0);
      if (bits.length >= 4) break;
    }
    
    // Pad to byte boundary
    while (bits.length % 8 !== 0) bits.push(0);
    
    // Pad codewords
    const padBytes = [0xEC, 0x11];
    let padIndex = 0;
    while (bits.length < capacity * 8) {
      const pad = padBytes[padIndex % 2];
      for (let i = 7; i >= 0; i--) {
        bits.push((pad >> i) & 1);
      }
      padIndex++;
    }
    
    return bits;
  }
  
  function getDataCapacity(version, ecl) {
    const capacities = [
      [19, 16, 13, 9],
      [34, 28, 22, 16],
      [55, 44, 34, 26],
      [80, 64, 48, 36],
      [108, 86, 62, 46],
      [136, 108, 76, 60],
      [156, 124, 88, 66],
      [194, 154, 110, 86],
      [232, 182, 132, 100],
      [271, 216, 154, 122],
    ];
    return capacities[version - 1][ecl];
  }
  
  function placeData(matrix, reserved, bits, size) {
    let bitIndex = 0;
    let upward = true;
    
    for (let col = size - 1; col >= 0; col -= 2) {
      if (col === 6) col = 5; // Skip timing pattern column
      
      for (let i = 0; i < size; i++) {
        const row = upward ? size - 1 - i : i;
        
        for (let c = 0; c < 2; c++) {
          const actualCol = col - c;
          if (!reserved[row][actualCol]) {
            matrix[row][actualCol] = bitIndex < bits.length ? bits[bitIndex] === 1 : false;
            bitIndex++;
          }
        }
      }
      upward = !upward;
    }
  }
  
  function applyBestMask(matrix, reserved, size, ecl) {
    let bestMask = 0;
    let bestScore = Infinity;
    
    for (let mask = 0; mask < 8; mask++) {
      const masked = applyMask(matrix, reserved, size, mask);
      addFormatInfo(masked, ecl, mask, size);
      const score = evaluateMask(masked, size);
      if (score < bestScore) {
        bestScore = score;
        bestMask = mask;
      }
    }
    
    const result = applyMask(matrix, reserved, size, bestMask);
    addFormatInfo(result, ecl, bestMask, size);
    return result;
  }
  
  function applyMask(matrix, reserved, size, mask) {
    const result = matrix.map(row => [...row]);
    
    for (let row = 0; row < size; row++) {
      for (let col = 0; col < size; col++) {
        if (reserved[row][col]) continue;
        
        let invert = false;
        switch (mask) {
          case 0: invert = (row + col) % 2 === 0; break;
          case 1: invert = row % 2 === 0; break;
          case 2: invert = col % 3 === 0; break;
          case 3: invert = (row + col) % 3 === 0; break;
          case 4: invert = (Math.floor(row / 2) + Math.floor(col / 3)) % 2 === 0; break;
          case 5: invert = (row * col) % 2 + (row * col) % 3 === 0; break;
          case 6: invert = ((row * col) % 2 + (row * col) % 3) % 2 === 0; break;
          case 7: invert = ((row + col) % 2 + (row * col) % 3) % 2 === 0; break;
        }
        
        if (invert) result[row][col] = !result[row][col];
      }
    }
    
    return result;
  }
  
  function addFormatInfo(matrix, ecl, mask, size) {
    const formatBits = getFormatBits(ecl, mask);
    
    // Place format info
    for (let i = 0; i < 6; i++) {
      matrix[8][i] = formatBits[i];
      matrix[i][8] = formatBits[14 - i];
    }
    matrix[8][7] = formatBits[6];
    matrix[8][8] = formatBits[7];
    matrix[7][8] = formatBits[8];
    
    for (let i = 0; i < 8; i++) {
      matrix[8][size - 8 + i] = formatBits[i];
      matrix[size - 1 - i][8] = formatBits[i];
    }
  }
  
  function getFormatBits(ecl, mask) {
    const formats = [
      [1,1,1,0,1,1,1,1,1,0,0,0,1,0,0], // L,0
      [1,1,1,0,0,1,0,1,1,1,1,0,0,1,1], // L,1
      [1,1,1,1,1,0,1,1,0,1,0,1,0,1,0], // L,2
      [1,1,1,1,0,0,0,1,0,0,1,1,1,0,1], // L,3
      [1,1,0,0,1,1,0,0,0,1,0,1,1,1,1], // L,4
      [1,1,0,0,0,1,1,0,0,0,1,1,0,0,0], // L,5
      [1,1,0,1,1,0,0,0,1,0,0,0,0,0,1], // L,6
      [1,1,0,1,0,0,1,0,1,1,1,0,1,1,0], // L,7
      [1,0,1,0,1,0,0,0,0,0,1,0,0,1,0], // M,0
      [1,0,1,0,0,0,1,0,0,1,0,0,1,0,1], // M,1
      [1,0,1,1,1,1,0,0,1,1,1,1,1,0,0], // M,2
      [1,0,1,1,0,1,1,0,1,0,0,1,0,1,1], // M,3
      [1,0,0,0,1,0,1,1,1,1,1,1,0,0,1], // M,4
      [1,0,0,0,0,0,0,1,1,0,0,1,1,1,0], // M,5
      [1,0,0,1,1,1,1,1,0,0,1,0,1,1,1], // M,6
      [1,0,0,1,0,1,0,1,0,1,0,0,0,0,0], // M,7
      [0,1,1,0,1,0,1,0,1,0,1,1,1,1,1], // Q,0
      [0,1,1,0,0,0,0,0,1,1,0,1,0,0,0], // Q,1
      [0,1,1,1,1,1,1,0,0,1,1,0,0,0,1], // Q,2
      [0,1,1,1,0,1,0,0,0,0,0,0,1,1,0], // Q,3
      [0,1,0,0,1,0,0,1,0,1,1,0,1,0,0], // Q,4
      [0,1,0,0,0,0,1,1,0,0,0,0,0,1,1], // Q,5
      [0,1,0,1,1,1,0,1,1,0,1,1,0,1,0], // Q,6
      [0,1,0,1,0,1,1,1,1,1,0,1,1,0,1], // Q,7
      [0,0,1,0,1,1,0,1,0,0,0,1,0,0,1], // H,0
      [0,0,1,0,0,1,1,1,0,1,1,1,1,1,0], // H,1
      [0,0,1,1,1,0,0,1,1,1,0,0,1,1,1], // H,2
      [0,0,1,1,0,0,1,1,1,0,1,0,0,0,0], // H,3
      [0,0,0,0,1,1,1,0,1,1,0,0,0,1,0], // H,4
      [0,0,0,0,0,1,0,0,1,0,1,0,1,0,1], // H,5
      [0,0,0,1,1,0,1,0,0,0,0,1,1,0,0], // H,6
      [0,0,0,1,0,0,0,0,0,1,1,1,0,1,1], // H,7
    ];
    
    const index = ecl * 8 + mask;
    return formats[index].map(b => b === 1);
  }
  
  function evaluateMask(matrix, size) {
    let score = 0;
    
    // Rule 1: Consecutive modules in row/column
    for (let row = 0; row < size; row++) {
      let count = 1;
      for (let col = 1; col < size; col++) {
        if (matrix[row][col] === matrix[row][col - 1]) {
          count++;
        } else {
          if (count >= 5) score += count - 2;
          count = 1;
        }
      }
      if (count >= 5) score += count - 2;
    }
    
    for (let col = 0; col < size; col++) {
      let count = 1;
      for (let row = 1; row < size; row++) {
        if (matrix[row][col] === matrix[row - 1][col]) {
          count++;
        } else {
          if (count >= 5) score += count - 2;
          count = 1;
        }
      }
      if (count >= 5) score += count - 2;
    }
    
    return score;
  }
  
  return { generateSVG };
})();

// Make available globally
if (typeof window !== 'undefined') {
  window.QRCode = QRCode;
}
