/**
 * PYRAX Wallet - Popup Script
 * Handles all UI interactions and communicates with the background service worker
 */

// State
let currentScreen = 'loading';
let walletState = null;
let generatedSeedPhrase = null;
let verifyWordIndex = 2; // Word #3 (0-indexed)

// DOM Elements cache
const screens = {
  loading: document.getElementById('loading-screen'),
  welcome: document.getElementById('welcome-screen'),
  lock: document.getElementById('lock-screen'),
  create: document.getElementById('create-screen'),
  import: document.getElementById('import-screen'),
  main: document.getElementById('main-screen'),
  send: document.getElementById('send-screen'),
  receive: document.getElementById('receive-screen'),
  settings: document.getElementById('settings-screen'),
  approval: document.getElementById('approval-screen')
};

// Initialize
document.addEventListener('DOMContentLoaded', init);

async function init() {
  console.log('Initializing PYRAX Wallet popup');
  
  // Get wallet state from background
  try {
    walletState = await sendMessage({ type: 'GET_WALLET_STATE' });
    console.log('Wallet state:', walletState);
    
    // Check for pending requests
    const { requests } = await sendMessage({ type: 'GET_PENDING_REQUESTS' });
    if (requests && requests.length > 0) {
      showApprovalScreen(requests[0]);
      return;
    }
    
    // Show appropriate screen
    if (!walletState.hasWallet) {
      showScreen('welcome');
    } else if (!walletState.isUnlocked) {
      showScreen('lock');
    } else {
      showScreen('main');
      loadMainScreen();
    }
  } catch (err) {
    console.error('Init error:', err);
    showScreen('welcome');
  }
  
  // Setup event listeners
  setupEventListeners();
}

// Communication with background script
function sendMessage(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else if (response?.error) {
        reject(new Error(response.error));
      } else {
        resolve(response);
      }
    });
  });
}

// Screen management
function showScreen(name) {
  Object.values(screens).forEach(screen => {
    if (screen) screen.classList.add('hidden');
  });
  if (screens[name]) {
    screens[name].classList.remove('hidden');
    currentScreen = name;
  }
}

// Event Listeners
function setupEventListeners() {
  // Welcome screen
  document.getElementById('btn-create-wallet')?.addEventListener('click', () => {
    showScreen('create');
    showCreateStep(1);
  });
  
  document.getElementById('btn-import-wallet')?.addEventListener('click', () => {
    showScreen('import');
  });
  
  // Lock screen
  document.getElementById('btn-unlock')?.addEventListener('click', handleUnlock);
  document.getElementById('unlock-password')?.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') handleUnlock();
  });
  
  // Create wallet - Step 1
  document.getElementById('btn-create-next-1')?.addEventListener('click', handleCreateStep1);
  
  // Create wallet - Step 2
  document.getElementById('seed-saved-checkbox')?.addEventListener('change', (e) => {
    document.getElementById('btn-create-next-2').disabled = !e.target.checked;
  });
  document.getElementById('btn-create-next-2')?.addEventListener('click', handleCreateStep2);
  
  // Create wallet - Step 3
  document.getElementById('btn-create-finish')?.addEventListener('click', handleCreateFinish);
  
  // Import wallet
  document.getElementById('tab-seed')?.addEventListener('click', () => {
    document.getElementById('tab-seed').classList.add('active');
    document.getElementById('tab-key').classList.remove('active');
    document.getElementById('import-seed-form').classList.remove('hidden');
    document.getElementById('import-key-form').classList.add('hidden');
  });
  
  document.getElementById('tab-key')?.addEventListener('click', () => {
    document.getElementById('tab-key').classList.add('active');
    document.getElementById('tab-seed').classList.remove('active');
    document.getElementById('import-key-form').classList.remove('hidden');
    document.getElementById('import-seed-form').classList.add('hidden');
  });
  
  document.getElementById('btn-import-submit')?.addEventListener('click', handleImport);
  
  // Back buttons
  document.getElementById('btn-back-create')?.addEventListener('click', () => showScreen('welcome'));
  document.getElementById('btn-back-import')?.addEventListener('click', () => showScreen('welcome'));
  document.getElementById('btn-back-send')?.addEventListener('click', () => showScreen('main'));
  document.getElementById('btn-back-receive')?.addEventListener('click', () => showScreen('main'));
  document.getElementById('btn-back-settings')?.addEventListener('click', () => showScreen('main'));
  
  // Main screen
  document.getElementById('btn-lock')?.addEventListener('click', handleLock);
  document.getElementById('btn-settings')?.addEventListener('click', () => showScreen('settings'));
  document.getElementById('btn-send')?.addEventListener('click', () => {
    showScreen('send');
    loadSendScreen();
  });
  document.getElementById('btn-receive')?.addEventListener('click', () => {
    showScreen('receive');
    loadReceiveScreen();
  });
  document.getElementById('btn-activity')?.addEventListener('click', () => {
    document.querySelectorAll('.main-tab').forEach(t => t.classList.remove('active'));
    document.querySelector('[data-tab="activity"]').classList.add('active');
    document.getElementById('tab-assets').classList.add('hidden');
    document.getElementById('tab-activity').classList.remove('hidden');
    document.getElementById('tab-connections').classList.add('hidden');
  });
  
  // Network selector
  document.getElementById('network-selector')?.addEventListener('click', toggleNetworkDropdown);
  document.querySelectorAll('.dropdown-item[data-network]').forEach(item => {
    item.addEventListener('click', () => handleNetworkChange(item.dataset.network));
  });
  
  // Copy address
  document.getElementById('btn-copy-address')?.addEventListener('click', copyAddress);
  document.getElementById('wallet-address')?.addEventListener('click', copyAddress);
  
  // Tabs
  document.querySelectorAll('.main-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.main-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      
      const tabName = tab.dataset.tab;
      document.getElementById('tab-assets').classList.toggle('hidden', tabName !== 'assets');
      document.getElementById('tab-activity').classList.toggle('hidden', tabName !== 'activity');
      document.getElementById('tab-connections').classList.toggle('hidden', tabName !== 'connections');
      
      if (tabName === 'connections') {
        loadConnections();
      }
    });
  });
  
  // Send
  document.getElementById('btn-send-max')?.addEventListener('click', handleSendMax);
  document.getElementById('btn-send-submit')?.addEventListener('click', handleSend);
  
  // Receive
  document.getElementById('btn-copy-receive')?.addEventListener('click', () => {
    navigator.clipboard.writeText(walletState.address);
    showToast('Address copied!');
  });
  
  // Settings
  document.getElementById('btn-export-key')?.addEventListener('click', handleExportKey);
  document.getElementById('btn-export-seed')?.addEventListener('click', handleExportSeed);
  document.getElementById('btn-reset-wallet')?.addEventListener('click', handleResetWallet);
  
  // Approval
  document.getElementById('btn-approve-tx')?.addEventListener('click', handleApproveTx);
  document.getElementById('btn-reject-tx')?.addEventListener('click', handleRejectTx);
  
  // Close dropdown when clicking outside
  document.addEventListener('click', (e) => {
    if (!e.target.closest('#network-selector') && !e.target.closest('#network-dropdown')) {
      document.getElementById('network-dropdown')?.classList.add('hidden');
    }
  });
}

// Unlock wallet
async function handleUnlock() {
  const password = document.getElementById('unlock-password').value;
  const errorEl = document.getElementById('unlock-error');
  
  if (!password) {
    errorEl.textContent = 'Please enter your password';
    errorEl.classList.remove('hidden');
    return;
  }
  
  try {
    const result = await sendMessage({ type: 'UNLOCK_WALLET', data: { password } });
    walletState.isUnlocked = true;
    walletState.address = result.address;
    showScreen('main');
    loadMainScreen();
  } catch (err) {
    errorEl.textContent = err.message || 'Invalid password';
    errorEl.classList.remove('hidden');
  }
}

// Lock wallet
async function handleLock() {
  await sendMessage({ type: 'LOCK_WALLET' });
  walletState.isUnlocked = false;
  showScreen('lock');
}

// Create wallet - Step 1
function handleCreateStep1() {
  const name = document.getElementById('create-name').value.trim();
  const password = document.getElementById('create-password').value;
  const confirm = document.getElementById('create-password-confirm').value;
  
  if (!name) {
    alert('Please enter a wallet name');
    return;
  }
  
  if (password.length < 8) {
    alert('Password must be at least 8 characters');
    return;
  }
  
  if (password !== confirm) {
    alert('Passwords do not match');
    return;
  }
  
  // Generate seed phrase
  generatedSeedPhrase = generateSeedPhrase();
  
  // Display seed phrase
  const grid = document.getElementById('seed-phrase-display');
  grid.innerHTML = '';
  generatedSeedPhrase.split(' ').forEach((word, i) => {
    const div = document.createElement('div');
    div.className = 'seed-word';
    div.innerHTML = `
      <span class="seed-word-num">${i + 1}</span>
      <span class="seed-word-text">${word}</span>
    `;
    grid.appendChild(div);
  });
  
  showCreateStep(2);
}

// Create wallet - Step 2
function handleCreateStep2() {
  // Pick random word to verify (between 1-12)
  verifyWordIndex = Math.floor(Math.random() * 12);
  document.getElementById('verify-word-num').textContent = verifyWordIndex + 1;
  document.getElementById('verify-word-input').value = '';
  document.getElementById('verify-error').classList.add('hidden');
  
  showCreateStep(3);
}

// Create wallet - Finish
async function handleCreateFinish() {
  const inputWord = document.getElementById('verify-word-input').value.trim().toLowerCase();
  const actualWord = generatedSeedPhrase.split(' ')[verifyWordIndex];
  
  if (inputWord !== actualWord) {
    document.getElementById('verify-error').textContent = 'Incorrect word. Please check your recovery phrase.';
    document.getElementById('verify-error').classList.remove('hidden');
    return;
  }
  
  const name = document.getElementById('create-name').value.trim();
  const password = document.getElementById('create-password').value;
  
  try {
    const result = await sendMessage({
      type: 'CREATE_WALLET',
      data: { name, password, seedPhrase: generatedSeedPhrase }
    });
    
    walletState = {
      hasWallet: true,
      isUnlocked: true,
      address: result.address
    };
    
    showScreen('main');
    loadMainScreen();
    
    // Clear sensitive data
    generatedSeedPhrase = null;
  } catch (err) {
    alert('Error creating wallet: ' + err.message);
  }
}

function showCreateStep(step) {
  document.getElementById('create-step-1').classList.toggle('hidden', step !== 1);
  document.getElementById('create-step-2').classList.toggle('hidden', step !== 2);
  document.getElementById('create-step-3').classList.toggle('hidden', step !== 3);
}

// Import wallet
async function handleImport() {
  const name = document.getElementById('import-name').value.trim() || 'Imported Wallet';
  const password = document.getElementById('import-password').value;
  const confirm = document.getElementById('import-password-confirm').value;
  const errorEl = document.getElementById('import-error');
  
  const usingSeed = !document.getElementById('import-seed-form').classList.contains('hidden');
  const seedPhrase = document.getElementById('import-seed')?.value.trim();
  const privateKey = document.getElementById('import-key')?.value.trim();
  
  if (password.length < 8) {
    errorEl.textContent = 'Password must be at least 8 characters';
    errorEl.classList.remove('hidden');
    return;
  }
  
  if (password !== confirm) {
    errorEl.textContent = 'Passwords do not match';
    errorEl.classList.remove('hidden');
    return;
  }
  
  if (usingSeed && (!seedPhrase || seedPhrase.split(/\s+/).length !== 12)) {
    errorEl.textContent = 'Please enter a valid 12-word recovery phrase';
    errorEl.classList.remove('hidden');
    return;
  }
  
  if (!usingSeed && (!privateKey || privateKey.length < 64)) {
    errorEl.textContent = 'Please enter a valid private key';
    errorEl.classList.remove('hidden');
    return;
  }
  
  try {
    const result = await sendMessage({
      type: 'IMPORT_WALLET',
      data: {
        name,
        password,
        seedPhrase: usingSeed ? seedPhrase : null,
        privateKey: usingSeed ? null : privateKey
      }
    });
    
    walletState = {
      hasWallet: true,
      isUnlocked: true,
      address: result.address
    };
    
    showScreen('main');
    loadMainScreen();
  } catch (err) {
    errorEl.textContent = err.message || 'Import failed';
    errorEl.classList.remove('hidden');
  }
}

// Main screen
async function loadMainScreen() {
  // Load wallet name
  const { walletName } = await chrome.storage.local.get(['walletName']);
  document.getElementById('wallet-name').textContent = walletName || 'My Wallet';
  
  // Display address
  const addr = walletState.address;
  document.getElementById('address-display').textContent = 
    addr ? `${addr.slice(0, 6)}...${addr.slice(-4)}` : '---';
  
  // Load network
  const networkResult = await sendMessage({ type: 'GET_NETWORK' });
  updateNetworkDisplay(networkResult);
  
  // Load balance
  await loadBalance();
  
  // Load transaction history
  await loadTransactions();
}

// Transaction History
async function loadTransactions() {
  const activityList = document.getElementById('activity-list');
  
  try {
    const result = await sendMessage({ type: 'GET_TRANSACTIONS' });
    const transactions = result.transactions || [];
    
    if (transactions.length === 0) {
      activityList.innerHTML = `
        <div class="empty-state">
          <span>📭</span>
          <p>No transactions yet</p>
        </div>
      `;
      return;
    }
    
    activityList.innerHTML = transactions.map(tx => {
      const isSend = tx.type === 'send' || tx.from?.toLowerCase() === walletState.address?.toLowerCase();
      const icon = isSend ? '📤' : '📥';
      const label = isSend ? 'Sent' : 'Received';
      const color = isSend ? 'text-red-400' : 'text-green-400';
      const amount = formatTxValue(tx.value);
      const time = formatTxTime(tx.timestamp);
      const addr = isSend ? tx.to : tx.from;
      const shortAddr = addr ? `${addr.slice(0, 6)}...${addr.slice(-4)}` : 'Unknown';
      const status = tx.status === 'pending' ? '⏳' : '✓';
      
      return `
        <div class="activity-item" data-hash="${tx.hash}">
          <div class="activity-icon">${icon}</div>
          <div class="activity-info">
            <div class="activity-label">${label} <span class="activity-status">${status}</span></div>
            <div class="activity-addr">${isSend ? 'To' : 'From'}: ${shortAddr}</div>
          </div>
          <div class="activity-amount ${color}">
            ${isSend ? '-' : '+'}${amount} PYRAX
          </div>
          <div class="activity-time">${time}</div>
        </div>
      `;
    }).join('');
    
    // Add click handlers to view on explorer
    activityList.querySelectorAll('.activity-item').forEach(item => {
      item.addEventListener('click', () => {
        const hash = item.dataset.hash;
        if (hash) {
          chrome.tabs.create({ url: `https://forge.pyrax.org/tx/${hash}` });
        }
      });
    });
    
  } catch (err) {
    console.error('Failed to load transactions:', err);
    activityList.innerHTML = `
      <div class="empty-state">
        <span>⚠️</span>
        <p>Could not load transactions</p>
      </div>
    `;
  }
}

function formatTxValue(value) {
  if (!value) return '0';
  try {
    const wei = BigInt(value);
    const pyrax = Number(wei) / 1e18;
    return pyrax.toFixed(4);
  } catch {
    return '0';
  }
}

function formatTxTime(timestamp) {
  if (!timestamp) return '';
  const date = new Date(timestamp);
  const now = new Date();
  const diff = now - date;
  
  if (diff < 60000) return 'Just now';
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
  if (diff < 604800000) return `${Math.floor(diff / 86400000)}d ago`;
  
  return date.toLocaleDateString();
}

async function loadBalance() {
  try {
    const result = await sendMessage({ type: 'GET_BALANCE' });
    document.getElementById('balance-amount').textContent = result.balanceFormatted;
    document.getElementById('asset-amount').textContent = result.balanceFormatted;
  } catch (err) {
    console.error('Failed to load balance:', err);
    document.getElementById('balance-amount').textContent = '0.0000';
  }
}

function updateNetworkDisplay(network) {
  document.getElementById('current-network').textContent = network.name;
  document.getElementById('asset-network').textContent = network.name;
  
  // Update dot color
  const dot = document.querySelector('.network-selector .network-dot');
  dot.className = 'network-dot ' + (network.network || 'forge');
}

// Network
function toggleNetworkDropdown() {
  document.getElementById('network-dropdown').classList.toggle('hidden');
}

async function handleNetworkChange(networkId) {
  document.getElementById('network-dropdown').classList.add('hidden');
  
  try {
    const result = await sendMessage({ type: 'SET_NETWORK', data: { network: networkId } });
    updateNetworkDisplay({ ...result.network, network: networkId });
    await loadBalance();
  } catch (err) {
    console.error('Network change failed:', err);
  }
}

// Copy address
function copyAddress() {
  navigator.clipboard.writeText(walletState.address);
  showToast('Copied!');
}

function showToast(message) {
  const toast = document.getElementById('copy-toast');
  toast.textContent = message;
  toast.classList.remove('hidden');
  setTimeout(() => toast.classList.add('hidden'), 2000);
}

// Send screen
async function loadSendScreen() {
  try {
    const result = await sendMessage({ type: 'GET_BALANCE' });
    document.getElementById('send-balance').textContent = result.balanceFormatted;
  } catch (err) {
    console.error('Failed to load balance:', err);
  }
}

function handleSendMax() {
  const balance = document.getElementById('send-balance').textContent;
  const maxAmount = parseFloat(balance) - 0.0001; // Reserve for gas
  document.getElementById('send-amount').value = Math.max(0, maxAmount).toFixed(4);
}

async function handleSend() {
  const to = document.getElementById('send-to').value.trim();
  const amount = document.getElementById('send-amount').value;
  const errorEl = document.getElementById('send-error');
  
  if (!to.match(/^0x[a-fA-F0-9]{40}$/)) {
    errorEl.textContent = 'Invalid recipient address';
    errorEl.classList.remove('hidden');
    return;
  }
  
  if (!amount || parseFloat(amount) <= 0) {
    errorEl.textContent = 'Invalid amount';
    errorEl.classList.remove('hidden');
    return;
  }
  
  try {
    const amountWei = '0x' + BigInt(Math.floor(parseFloat(amount) * 1e18)).toString(16);
    
    const result = await sendMessage({
      type: 'SEND_TRANSACTION',
      data: { to, value: amountWei }
    });
    
    alert(`Transaction sent!\nTX: ${result.txHash}`);
    showScreen('main');
    loadBalance();
  } catch (err) {
    errorEl.textContent = err.message || 'Transaction failed';
    errorEl.classList.remove('hidden');
  }
}

// Receive screen
function loadReceiveScreen() {
  const address = walletState.address;
  document.getElementById('receive-address').textContent = address;
  
  // Generate actual QR code using our QRCode library
  const qrContainer = document.getElementById('qr-code');
  try {
    const qrSvg = QRCode.generateSVG(address, {
      size: 200,
      margin: 2,
      dark: '#0A0A0B',
      light: '#ffffff',
      ecl: 'M'
    });
    qrContainer.innerHTML = qrSvg;
  } catch (err) {
    console.error('QR generation failed:', err);
    // Fallback to address display
    qrContainer.innerHTML = `
      <div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:#fff;color:#333;font-size:10px;text-align:center;padding:10px;">
        ${address}
      </div>
    `;
  }
}

// Connections
async function loadConnections() {
  try {
    const { sites } = await sendMessage({ type: 'GET_CONNECTED_SITES' });
    const list = document.getElementById('connections-list');
    
    const siteArray = Object.entries(sites);
    
    if (siteArray.length === 0) {
      list.innerHTML = `
        <div class="empty-state">
          <span>🔗</span>
          <p>No connected sites</p>
        </div>
      `;
      return;
    }
    
    list.innerHTML = siteArray.map(([origin, data]) => `
      <div class="connection-item" data-origin="${origin}">
        <div class="connection-icon">🌐</div>
        <div class="connection-info">
          <div class="connection-name">${new URL(origin).hostname}</div>
          <div class="connection-time">Connected ${formatTime(data.connectedAt)}</div>
        </div>
        <button class="disconnect-btn" data-origin="${origin}">Disconnect</button>
      </div>
    `).join('');
    
    // Add disconnect listeners
    list.querySelectorAll('.disconnect-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        await sendMessage({ type: 'DISCONNECT_SITE', data: { origin: btn.dataset.origin } });
        loadConnections();
      });
    });
  } catch (err) {
    console.error('Failed to load connections:', err);
  }
}

function formatTime(timestamp) {
  const diff = Date.now() - timestamp;
  if (diff < 60000) return 'just now';
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
  return `${Math.floor(diff / 86400000)}d ago`;
}

// Settings
async function handleExportKey() {
  const password = prompt('Enter your password to export private key:');
  if (!password) return;
  
  try {
    await sendMessage({ type: 'UNLOCK_WALLET', data: { password } });
    const { privateKey } = await chrome.storage.local.get(['privateKey']);
    
    if (privateKey) {
      const confirmed = confirm(
        '⚠️ WARNING: Never share your private key!\n\n' +
        'Anyone with your private key can steal all your funds.\n\n' +
        'Click OK to copy to clipboard.'
      );
      
      if (confirmed) {
        navigator.clipboard.writeText(privateKey);
        alert('Private key copied to clipboard.\n\nClear your clipboard after saving it securely!');
      }
    }
  } catch (err) {
    alert('Invalid password');
  }
}

async function handleExportSeed() {
  alert('Seed phrase export requires re-entering your recovery phrase.\n\nThis feature will be available in a future update.');
}

async function handleResetWallet() {
  const confirmed = confirm(
    '⚠️ DANGER: This will delete your wallet!\n\n' +
    'Make sure you have your recovery phrase backed up.\n\n' +
    'This action cannot be undone!'
  );
  
  if (confirmed) {
    const doubleConfirm = prompt('Type "DELETE" to confirm:');
    if (doubleConfirm === 'DELETE') {
      await chrome.storage.local.clear();
      walletState = { hasWallet: false, isUnlocked: false };
      showScreen('welcome');
    }
  }
}

// Transaction approval
let currentApprovalRequest = null;

function showApprovalScreen(request) {
  currentApprovalRequest = request;
  
  document.getElementById('approval-site-name').textContent = new URL(request.origin).hostname;
  document.getElementById('approval-to').textContent = 
    request.params.to ? `${request.params.to.slice(0, 10)}...${request.params.to.slice(-8)}` : 'Contract';
  
  const value = request.params.value ? parseInt(request.params.value, 16) / 1e18 : 0;
  document.getElementById('approval-amount').textContent = `${value.toFixed(4)} PYRAX`;
  
  showScreen('approval');
}

async function handleApproveTx() {
  if (!currentApprovalRequest) return;
  
  try {
    await sendMessage({ type: 'APPROVE_TRANSACTION', data: { requestId: currentApprovalRequest.id } });
    showScreen('main');
    loadMainScreen();
  } catch (err) {
    alert('Transaction failed: ' + err.message);
  }
}

async function handleRejectTx() {
  if (!currentApprovalRequest) return;
  
  await sendMessage({ type: 'REJECT_TRANSACTION', data: { requestId: currentApprovalRequest.id } });
  currentApprovalRequest = null;
  showScreen('main');
}

// Seed phrase generator (simplified BIP39)
function generateSeedPhrase() {
  const wordlist = [
    'abandon', 'ability', 'able', 'about', 'above', 'absent', 'absorb', 'abstract',
    'absurd', 'abuse', 'access', 'accident', 'account', 'accuse', 'achieve', 'acid',
    'acoustic', 'acquire', 'across', 'act', 'action', 'actor', 'actress', 'actual',
    'adapt', 'add', 'addict', 'address', 'adjust', 'admit', 'adult', 'advance',
    'advice', 'aerobic', 'affair', 'afford', 'afraid', 'again', 'age', 'agent',
    'agree', 'ahead', 'aim', 'air', 'airport', 'aisle', 'alarm', 'album',
    'alcohol', 'alert', 'alien', 'all', 'alley', 'allow', 'almost', 'alone',
    'alpha', 'already', 'also', 'alter', 'always', 'amateur', 'amazing', 'among',
    'amount', 'amused', 'analyst', 'anchor', 'ancient', 'anger', 'angle', 'angry',
    'animal', 'ankle', 'announce', 'annual', 'another', 'answer', 'antenna', 'antique',
    'anxiety', 'any', 'apart', 'apology', 'appear', 'apple', 'approve', 'april',
    'arch', 'arctic', 'area', 'arena', 'argue', 'arm', 'armed', 'armor',
    'army', 'around', 'arrange', 'arrest', 'arrive', 'arrow', 'art', 'artefact',
    'artist', 'artwork', 'ask', 'aspect', 'assault', 'asset', 'assist', 'assume',
    'asthma', 'athlete', 'atom', 'attack', 'attend', 'attitude', 'attract', 'auction',
    'audit', 'august', 'aunt', 'author', 'auto', 'autumn', 'average', 'avocado',
    'avoid', 'awake', 'aware', 'away', 'awesome', 'awful', 'awkward', 'axis',
    'baby', 'bachelor', 'bacon', 'badge', 'bag', 'balance', 'balcony', 'ball',
    'bamboo', 'banana', 'banner', 'bar', 'barely', 'bargain', 'barrel', 'base',
    'basic', 'basket', 'battle', 'beach', 'bean', 'beauty', 'because', 'become',
    'beef', 'before', 'begin', 'behave', 'behind', 'believe', 'below', 'belt',
    'bench', 'benefit', 'best', 'betray', 'better', 'between', 'beyond', 'bicycle',
    'bid', 'bike', 'bind', 'biology', 'bird', 'birth', 'bitter', 'black',
    'blade', 'blame', 'blanket', 'blast', 'bleak', 'bless', 'blind', 'blood',
    'blossom', 'blouse', 'blue', 'blur', 'blush', 'board', 'boat', 'body',
    'boil', 'bomb', 'bone', 'bonus', 'book', 'boost', 'border', 'boring',
    'borrow', 'boss', 'bottom', 'bounce', 'box', 'boy', 'bracket', 'brain',
    'brand', 'brass', 'brave', 'bread', 'breeze', 'brick', 'bridge', 'brief',
    'bright', 'bring', 'brisk', 'broccoli', 'broken', 'bronze', 'broom', 'brother',
    'brown', 'brush', 'bubble', 'buddy', 'budget', 'buffalo', 'build', 'bulb',
    'bulk', 'bullet', 'bundle', 'bunker', 'burden', 'burger', 'burst', 'bus',
    'business', 'busy', 'butter', 'buyer', 'buzz', 'cabbage', 'cabin', 'cable',
    'cactus', 'cage', 'cake', 'call', 'calm', 'camera', 'camp', 'can',
    'canal', 'cancel', 'candy', 'cannon', 'canoe', 'canvas', 'canyon', 'capable',
    'capital', 'captain', 'car', 'carbon', 'card', 'cargo', 'carpet', 'carry',
    'cart', 'case', 'cash', 'casino', 'castle', 'casual', 'cat', 'catalog',
    'catch', 'category', 'cattle', 'caught', 'cause', 'caution', 'cave', 'ceiling',
    'celery', 'cement', 'census', 'century', 'cereal', 'certain', 'chair', 'chalk'
  ];
  
  const words = [];
  const entropy = new Uint8Array(16);
  crypto.getRandomValues(entropy);
  
  for (let i = 0; i < 12; i++) {
    const index = (entropy[i] + (entropy[(i + 1) % 16] << 8)) % wordlist.length;
    words.push(wordlist[index]);
  }
  
  return words.join(' ');
}

// Listen for messages from background
chrome.runtime.onMessage.addListener((message) => {
  switch (message.type) {
    case 'WALLET_UNLOCKED':
      if (currentScreen === 'lock') {
        walletState.isUnlocked = true;
        walletState.address = message.address;
        showScreen('main');
        loadMainScreen();
      }
      break;
      
    case 'WALLET_LOCKED':
      if (currentScreen === 'main') {
        showScreen('lock');
      }
      break;
      
    case 'NETWORK_CHANGED':
      if (currentScreen === 'main') {
        loadBalance();
      }
      break;
  }
});

console.log('PYRAX Wallet popup script loaded');
