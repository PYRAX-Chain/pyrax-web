# PYRAX Wallet - Chrome Extension

The official PYRAX blockchain wallet extension for Chrome and Chromium-based browsers.

## Features

- **Create & Import Wallets** - Generate new wallets with BIP39 seed phrases or import existing ones
- **Send & Receive PYRAX** - Full transaction support with real-time balance updates
- **dApp Integration** - Connect to PYRAX dApps with EIP-1193 standard provider
- **Multi-Network Support** - DevNet, Forge Testnet, and Mainnet
- **Security** - AES-256 encryption, password protection, auto-lock
- **Transaction Approval** - Popup confirmations for all transactions

## Installation

### Method 1: Developer Mode (Recommended for Testing)

1. Download or clone this repository
2. Open Chrome and go to `chrome://extensions`
3. Enable "Developer mode" (toggle in top right)
4. Click "Load unpacked"
5. Select the `pyrax-chrome-extension` folder
6. The PYRAX Wallet icon will appear in your toolbar

### Method 2: Self-Hosted .crx File

1. Download the `.crx` file from [pyrax.org/firelink](https://pyrax.org/firelink)
2. Open Chrome and go to `chrome://extensions`
3. Drag and drop the `.crx` file onto the page
4. Click "Add extension" when prompted

## Usage

### Creating a New Wallet

1. Click the PYRAX Wallet icon in your toolbar
2. Click "Create New Wallet"
3. Set a name and strong password
4. **IMPORTANT**: Write down your 12-word recovery phrase
5. Complete the security verification
6. Your wallet is ready!

### Importing an Existing Wallet

1. Click "Import Existing Wallet"
2. Choose "Seed Phrase" or "Private Key"
3. Enter your recovery phrase or private key
4. Set a password
5. Click "Import Wallet"

### Connecting to dApps

When you visit a PYRAX-enabled website:

1. The site will request wallet connection
2. A popup will appear asking for permission
3. Click "Connect" to allow access
4. Your address will be shared with the site

### Sending PYRAX

1. Click the PYRAX Wallet icon
2. Click "Send"
3. Enter the recipient address
4. Enter the amount
5. Click "Send"
6. Confirm the transaction

## Security

- **Never share your recovery phrase** - Anyone with these words can steal your funds
- **Use a strong password** - At least 8 characters, mix of letters/numbers/symbols
- **Verify addresses** - Always double-check recipient addresses before sending
- **Auto-lock** - The wallet automatically locks after 15 minutes of inactivity

## Networks

| Network | Chain ID | RPC URL |
|---------|----------|---------|
| DevNet | 789120 | http://127.0.0.1:8546 |
| Forge Testnet | 789121 | https://forge-rpc.pyrax.org |
| Mainnet | 789100 | https://rpc.pyrax.org |

## Development

```bash
# Clone the repository
git clone https://github.com/PYRAX-Chain/pyrax-chrome-extension.git

# Load in Chrome
# 1. Go to chrome://extensions
# 2. Enable Developer mode
# 3. Click "Load unpacked"
# 4. Select the pyrax-chrome-extension folder
```

## Building .crx File

```bash
# Pack the extension
# 1. Go to chrome://extensions
# 2. Click "Pack extension"
# 3. Select the pyrax-chrome-extension folder
# 4. Chrome will generate .crx and .pem files
```

## Support

- Website: [pyrax.org](https://pyrax.org)
- Documentation: [docs.pyrax.org](https://docs.pyrax.org)
- Discord: [discord.gg/pyrax](https://discord.gg/pyrax)

## License

MIT License - see LICENSE file for details.

---

**PYRAX Wallet v1.0.0** | Built with 🔥 by the PYRAX Team
