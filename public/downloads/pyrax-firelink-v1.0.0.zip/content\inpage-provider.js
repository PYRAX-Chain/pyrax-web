/**
 * PYRAX Wallet - Content Script
 * Injects the EIP-1193 provider into web pages
 */

// Inject the provider script into the page
function injectScript() {
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('content/injected.js');
  script.onload = function() {
    this.remove();
  };
  (document.head || document.documentElement).appendChild(script);
}

injectScript();

// Bridge between page and extension
window.addEventListener('message', async (event) => {
  if (event.source !== window) return;
  if (event.data.target !== 'pyrax-extension') return;

  const { id, method, params } = event.data;

  try {
    const response = await chrome.runtime.sendMessage({
      type: 'ETH_REQUEST',
      data: { method, params }
    });

    window.postMessage({
      target: 'pyrax-page',
      id,
      result: response
    }, '*');
  } catch (error) {
    window.postMessage({
      target: 'pyrax-page',
      id,
      error: { message: error.message, code: 4001 }
    }, '*');
  }
});

// Listen for events from background script
chrome.runtime.onMessage.addListener((message) => {
  switch (message.type) {
    case 'WALLET_UNLOCKED':
      window.postMessage({
        target: 'pyrax-page',
        event: 'accountsChanged',
        data: [message.address]
      }, '*');
      break;

    case 'WALLET_LOCKED':
      window.postMessage({
        target: 'pyrax-page',
        event: 'accountsChanged',
        data: []
      }, '*');
      break;

    case 'NETWORK_CHANGED':
      window.postMessage({
        target: 'pyrax-page',
        event: 'chainChanged',
        data: message.chainId
      }, '*');
      break;
  }
});

console.log('PYRAX Wallet content script loaded');
