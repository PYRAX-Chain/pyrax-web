/**
 * PYRAX Wallet - Injected Provider (EIP-1193)
 * This script runs in the page context and provides window.ethereum / window.pyrax
 */

(function() {
  'use strict';

  // Request ID counter
  let requestId = 0;
  const pendingRequests = new Map();

  // Event emitter
  class EventEmitter {
    constructor() {
      this.events = {};
    }

    on(event, listener) {
      if (!this.events[event]) this.events[event] = [];
      this.events[event].push(listener);
      return this;
    }

    removeListener(event, listener) {
      if (!this.events[event]) return this;
      this.events[event] = this.events[event].filter(l => l !== listener);
      return this;
    }

    emit(event, ...args) {
      if (!this.events[event]) return false;
      this.events[event].forEach(listener => listener(...args));
      return true;
    }
  }

  // PYRAX Provider (EIP-1193 compliant)
  class PyraxProvider extends EventEmitter {
    constructor() {
      super();
      // Firelink identification flags
      this.isFirelink = true;
      this.isPYRAX = true;
      this.isPyrax = true;
      this.isMetaMask = false; // Don't pretend to be MetaMask
      this.selectedAddress = null;
      this.chainId = '0xc0c21'; // Forge testnet default
      this.networkVersion = '789121';
      this._isConnected = false;
      this._providerName = 'Firelink';
    }

    get isConnected() {
      return this._isConnected;
    }

    async request({ method, params = [] }) {
      const id = ++requestId;

      return new Promise((resolve, reject) => {
        pendingRequests.set(id, { resolve, reject });

        window.postMessage({
          target: 'pyrax-extension',
          id,
          method,
          params
        }, '*');

        // Timeout after 60 seconds
        setTimeout(() => {
          if (pendingRequests.has(id)) {
            pendingRequests.delete(id);
            reject(new Error('Request timeout'));
          }
        }, 60000);
      });
    }

    // Legacy methods for compatibility
    async enable() {
      return this.request({ method: 'eth_requestAccounts' });
    }

    send(methodOrPayload, paramsOrCallback) {
      if (typeof methodOrPayload === 'string') {
        return this.request({ method: methodOrPayload, params: paramsOrCallback });
      }
      
      if (typeof paramsOrCallback === 'function') {
        this.request(methodOrPayload)
          .then(result => paramsOrCallback(null, { result }))
          .catch(error => paramsOrCallback(error, null));
        return;
      }

      return this.request(methodOrPayload);
    }

    sendAsync(payload, callback) {
      this.request(payload)
        .then(result => callback(null, { id: payload.id, jsonrpc: '2.0', result }))
        .catch(error => callback(error, null));
    }

    // Internal: update connection state
    _handleConnect(chainId) {
      this._isConnected = true;
      this.chainId = chainId;
      this.emit('connect', { chainId });
    }

    _handleDisconnect() {
      this._isConnected = false;
      this.selectedAddress = null;
      this.emit('disconnect', { code: 4900, message: 'Disconnected' });
    }

    _handleChainChanged(chainId) {
      this.chainId = chainId;
      this.emit('chainChanged', chainId);
    }

    _handleAccountsChanged(accounts) {
      this.selectedAddress = accounts[0] || null;
      this.emit('accountsChanged', accounts);
    }
  }

  // Create provider instance
  const provider = new PyraxProvider();

  // Listen for responses from content script
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    if (event.data.target !== 'pyrax-page') return;

    const { id, result, error, event: eventName, data } = event.data;

    // Handle responses
    if (id !== undefined) {
      const pending = pendingRequests.get(id);
      if (pending) {
        pendingRequests.delete(id);
        if (error) {
          pending.reject(new Error(error.message));
        } else {
          // Update state based on method results
          if (Array.isArray(result) && result[0]?.startsWith('0x')) {
            provider.selectedAddress = result[0];
            provider._isConnected = true;
          }
          pending.resolve(result);
        }
      }
    }

    // Handle events
    if (eventName) {
      switch (eventName) {
        case 'accountsChanged':
          provider._handleAccountsChanged(data);
          break;
        case 'chainChanged':
          provider._handleChainChanged(data);
          break;
        case 'connect':
          provider._handleConnect(data);
          break;
        case 'disconnect':
          provider._handleDisconnect();
          break;
      }
    }
  });

  // Announce provider (EIP-6963)
  function announceProvider() {
    const info = {
      uuid: 'firelink-wallet-v1',
      name: 'Firelink',
      icon: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIxNiIgY3k9IjE2IiByPSIxNiIgZmlsbD0iI0Y2ODcyNCIvPjxwYXRoIGQ9Ik0xNiA2YzIgNCA0IDggMiAxMnMtNiA2LTYgNmMwIDAgMi0yIDItNnMtMi02LTItNmMwIDAgMi0yIDQtNnoiIGZpbGw9IiNmZmYiLz48cGF0aCBkPSJNMTYgMTBjMSAyIDIgNCAxIDZzLTMgMy0zIDNjMCAwIDEtMSAxLTNzLTEtMy0xLTNjMCAwIDEtMSAyLTN6IiBmaWxsPSIjRkZBNTAwIi8+PC9zdmc+',
      rdns: 'org.pyrax.firelink'
    };

    window.dispatchEvent(new CustomEvent('eip6963:announceProvider', {
      detail: Object.freeze({ info, provider })
    }));
  }

  // Listen for provider requests (EIP-6963)
  window.addEventListener('eip6963:requestProvider', announceProvider);

  // Inject provider
  Object.defineProperty(window, 'pyrax', {
    value: provider,
    writable: false,
    configurable: false
  });

  // Also set as ethereum if not already set (for compatibility)
  if (!window.ethereum) {
    Object.defineProperty(window, 'ethereum', {
      value: provider,
      writable: false,
      configurable: false
    });
  } else {
    // If ethereum exists, add pyrax to providers array
    if (window.ethereum.providers) {
      window.ethereum.providers.push(provider);
    } else {
      window.ethereum.providers = [window.ethereum, provider];
    }
  }

  // Announce on load
  announceProvider();

  console.log('🔥 Firelink wallet provider injected');
})();
