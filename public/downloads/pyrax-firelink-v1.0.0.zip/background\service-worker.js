/**
 * PYRAX Wallet - Background Service Worker
 * Handles wallet operations, cross-tab sync, and dApp connections
 */

// Network configurations
const NETWORKS = {
  devnet: {
    chainId: 789120,
    chainIdHex: '0xc0c20',
    name: 'DevNet (Local)',
    rpcUrl: 'http://127.0.0.1:8546',
    symbol: 'PYRAX',
    decimals: 18,
    explorer: 'http://localhost:3001',
    isTestnet: true
  },
  forge: {
    chainId: 789121,
    chainIdHex: '0xc0c21',
    name: 'Forge Testnet',
    rpcUrl: 'https://forge-rpc.pyrax.org',
    symbol: 'PYRAX',
    decimals: 18,
    explorer: 'https://forge.pyrax.org',
    isTestnet: true
  },
  mainnet: {
    chainId: 789100,
    chainIdHex: '0xc0bfc',
    name: 'PYRAX Mainnet',
    rpcUrl: 'https://rpc.pyrax.org',
    symbol: 'PYRAX',
    decimals: 18,
    explorer: 'https://explorer.pyrax.org',
    isTestnet: false
  }
};

// State
let currentNetwork = 'forge';
let connectedSites = {};
let pendingRequests = {};

// Initialize
chrome.runtime.onInstalled.addListener(() => {
  console.log('PYRAX Wallet installed');
  chrome.storage.local.set({ 
    network: 'forge',
    connectedSites: {},
    pendingTxCount: 0
  });
  updateBadge(0);
});

// Badge management
function updateBadge(count) {
  if (count > 0) {
    chrome.action.setBadgeText({ text: count.toString() });
    chrome.action.setBadgeBackgroundColor({ color: '#F68724' });
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}

// Message handler from popup and content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender).then(sendResponse).catch(err => {
    console.error('Message handler error:', err);
    sendResponse({ error: err.message });
  });
  return true; // Keep channel open for async response
});

async function handleMessage(message, sender) {
  const { type, data } = message;

  switch (type) {
    // Wallet operations
    case 'GET_WALLET_STATE':
      return getWalletState();

    case 'UNLOCK_WALLET':
      return unlockWallet(data.password);

    case 'LOCK_WALLET':
      return lockWallet();

    case 'CREATE_WALLET':
      return createWallet(data);

    case 'IMPORT_WALLET':
      return importWallet(data);

    case 'GET_BALANCE':
      return getBalance();

    case 'SEND_TRANSACTION':
      return sendTransaction(data);

    case 'GET_TRANSACTIONS':
      return getTransactions();

    case 'ADD_EXTERNAL_TX':
      return addExternalTransaction(data);

    case 'SIGN_MESSAGE':
      return signMessage(data);

    // Network operations
    case 'GET_NETWORK':
      return getNetwork();

    case 'SET_NETWORK':
      return setNetwork(data.network);

    case 'GET_NETWORKS':
      return { networks: NETWORKS };

    // dApp connection
    case 'CONNECT_SITE':
      return connectSite(data.origin);

    case 'DISCONNECT_SITE':
      return disconnectSite(data.origin);

    case 'IS_SITE_CONNECTED':
      return isSiteConnected(data.origin);

    case 'GET_CONNECTED_SITES':
      return getConnectedSites();

    // Transaction approval
    case 'APPROVE_TRANSACTION':
      return approveTransaction(data.requestId);

    case 'REJECT_TRANSACTION':
      return rejectTransaction(data.requestId);

    case 'GET_PENDING_REQUESTS':
      return { requests: Object.values(pendingRequests) };

    // EIP-1193 requests from content script
    case 'ETH_REQUEST':
      return handleEthRequest(data, sender);

    default:
      throw new Error(`Unknown message type: ${type}`);
  }
}

// Wallet State
async function getWalletState() {
  const result = await chrome.storage.local.get(['wallet', 'isUnlocked', 'network', 'address']);
  return {
    hasWallet: !!result.wallet,
    isUnlocked: result.isUnlocked || false,
    network: result.network || 'forge',
    address: result.isUnlocked ? result.address : null
  };
}

// Unlock wallet
async function unlockWallet(password) {
  const result = await chrome.storage.local.get(['wallet']);
  if (!result.wallet) {
    throw new Error('No wallet found');
  }

  try {
    const decrypted = await decryptWallet(result.wallet, password);
    await chrome.storage.local.set({ 
      isUnlocked: true, 
      address: decrypted.address,
      privateKey: decrypted.privateKey // Stored only in session
    });
    
    // Notify all tabs
    broadcastToTabs({ type: 'WALLET_UNLOCKED', address: decrypted.address });
    
    return { success: true, address: decrypted.address };
  } catch (err) {
    throw new Error('Invalid password');
  }
}

// Lock wallet
async function lockWallet() {
  await chrome.storage.local.remove(['isUnlocked', 'privateKey']);
  broadcastToTabs({ type: 'WALLET_LOCKED' });
  return { success: true };
}

// Create wallet
async function createWallet({ name, password, seedPhrase }) {
  const wallet = await generateWallet(seedPhrase);
  const encrypted = await encryptWallet(wallet, password);
  
  await chrome.storage.local.set({
    wallet: encrypted,
    walletName: name,
    isUnlocked: true,
    address: wallet.address,
    privateKey: wallet.privateKey
  });

  broadcastToTabs({ type: 'WALLET_CREATED', address: wallet.address });
  
  return { 
    success: true, 
    address: wallet.address,
    seedPhrase: wallet.seedPhrase
  };
}

// Import wallet
async function importWallet({ name, privateKey, seedPhrase, password }) {
  let wallet;
  
  if (seedPhrase) {
    wallet = await generateWallet(seedPhrase);
  } else if (privateKey) {
    wallet = await walletFromPrivateKey(privateKey);
  } else {
    throw new Error('Provide either seed phrase or private key');
  }

  const encrypted = await encryptWallet(wallet, password);
  
  await chrome.storage.local.set({
    wallet: encrypted,
    walletName: name,
    isUnlocked: true,
    address: wallet.address,
    privateKey: wallet.privateKey
  });

  broadcastToTabs({ type: 'WALLET_IMPORTED', address: wallet.address });
  
  return { success: true, address: wallet.address };
}

// Get balance
async function getBalance() {
  const result = await chrome.storage.local.get(['address', 'network']);
  if (!result.address) {
    throw new Error('Wallet not unlocked');
  }

  const network = NETWORKS[result.network || 'forge'];
  const balance = await rpcCall(network.rpcUrl, 'eth_getBalance', [result.address, 'latest']);
  
  return {
    balance: balance,
    balanceFormatted: formatBalance(balance),
    symbol: network.symbol
  };
}

// Send transaction
async function sendTransaction({ to, value, data: txData, gasLimit, gasPrice }) {
  const result = await chrome.storage.local.get(['address', 'privateKey', 'network']);
  if (!result.privateKey) {
    throw new Error('Wallet not unlocked');
  }

  const network = NETWORKS[result.network || 'forge'];
  
  // Get nonce
  const nonce = await rpcCall(network.rpcUrl, 'eth_getTransactionCount', [result.address, 'latest']);
  
  // Build transaction
  const tx = {
    from: result.address,
    to,
    value: value || '0x0',
    data: txData || '0x',
    nonce,
    gasLimit: gasLimit || '0x5208', // 21000
    gasPrice: gasPrice || '0x3b9aca00', // 1 gwei
    chainId: network.chainIdHex
  };

  // Sign and send
  const signedTx = await signTransaction(tx, result.privateKey);
  const txHash = await rpcCall(network.rpcUrl, 'eth_sendRawTransaction', [signedTx]);

  // Save to transaction history
  await saveTransaction({
    hash: txHash,
    from: result.address,
    to,
    value: value || '0x0',
    type: 'send',
    status: 'pending',
    timestamp: Date.now(),
    network: result.network || 'forge'
  });

  // Show notification
  chrome.notifications.create({
    type: 'basic',
    iconUrl: '../icons/icon128.png',
    title: 'Transaction Sent',
    message: `TX: ${txHash.slice(0, 10)}...${txHash.slice(-8)}`
  });

  return { txHash };
}

// Transaction History
async function getTransactions() {
  const result = await chrome.storage.local.get(['transactions', 'address', 'network']);
  const allTxs = result.transactions || [];
  const network = result.network || 'forge';
  const address = result.address?.toLowerCase();
  
  // Filter transactions for current address and network
  const filtered = allTxs.filter(tx => 
    tx.network === network && 
    (tx.from?.toLowerCase() === address || tx.to?.toLowerCase() === address)
  );
  
  // Sort by timestamp descending (newest first)
  filtered.sort((a, b) => b.timestamp - a.timestamp);
  
  // Also try to fetch recent transactions from RPC
  try {
    const networkConfig = NETWORKS[network];
    if (networkConfig && address) {
      const rpcTxs = await rpcCall(networkConfig.rpcUrl, 'pyrax_getAddressTransactions', [result.address, 20]);
      if (Array.isArray(rpcTxs)) {
        // Merge with local transactions
        for (const tx of rpcTxs) {
          const exists = filtered.find(t => t.hash === tx.hash);
          if (!exists) {
            filtered.push({
              hash: tx.hash,
              from: tx.from,
              to: tx.to,
              value: tx.value || tx.amount,
              type: tx.from?.toLowerCase() === address ? 'send' : 'receive',
              status: 'confirmed',
              timestamp: tx.timestamp * 1000 || Date.now(),
              network,
              blockNumber: tx.blockNumber
            });
          }
        }
        filtered.sort((a, b) => b.timestamp - a.timestamp);
      }
    }
  } catch (err) {
    console.log('Could not fetch RPC transactions:', err.message);
  }
  
  return { transactions: filtered.slice(0, 50) }; // Return last 50
}

async function saveTransaction(tx) {
  const result = await chrome.storage.local.get(['transactions']);
  const transactions = result.transactions || [];
  
  // Check if already exists
  const existingIndex = transactions.findIndex(t => t.hash === tx.hash);
  if (existingIndex >= 0) {
    transactions[existingIndex] = { ...transactions[existingIndex], ...tx };
  } else {
    transactions.unshift(tx);
  }
  
  // Keep only last 100 transactions
  if (transactions.length > 100) {
    transactions.length = 100;
  }
  
  await chrome.storage.local.set({ transactions });
}

async function addExternalTransaction(tx) {
  const result = await chrome.storage.local.get(['address', 'network']);
  
  await saveTransaction({
    ...tx,
    network: tx.network || result.network || 'forge',
    timestamp: tx.timestamp || Date.now(),
    status: tx.status || 'confirmed'
  });
  
  return { success: true };
}

// Network operations
async function getNetwork() {
  const result = await chrome.storage.local.get(['network']);
  const networkId = result.network || 'forge';
  return { network: networkId, ...NETWORKS[networkId] };
}

async function setNetwork(networkId) {
  if (!NETWORKS[networkId]) {
    throw new Error(`Unknown network: ${networkId}`);
  }
  
  await chrome.storage.local.set({ network: networkId });
  broadcastToTabs({ type: 'NETWORK_CHANGED', network: networkId, chainId: NETWORKS[networkId].chainIdHex });
  
  return { success: true, network: NETWORKS[networkId] };
}

// Site connection
async function connectSite(origin) {
  const result = await chrome.storage.local.get(['connectedSites', 'address']);
  const sites = result.connectedSites || {};
  
  sites[origin] = {
    connectedAt: Date.now(),
    address: result.address
  };
  
  await chrome.storage.local.set({ connectedSites: sites });
  
  return { success: true, address: result.address };
}

async function disconnectSite(origin) {
  const result = await chrome.storage.local.get(['connectedSites']);
  const sites = result.connectedSites || {};
  
  delete sites[origin];
  
  await chrome.storage.local.set({ connectedSites: sites });
  
  return { success: true };
}

async function isSiteConnected(origin) {
  const result = await chrome.storage.local.get(['connectedSites', 'isUnlocked']);
  const sites = result.connectedSites || {};
  
  return { 
    connected: !!sites[origin] && result.isUnlocked,
    address: sites[origin]?.address
  };
}

async function getConnectedSites() {
  const result = await chrome.storage.local.get(['connectedSites']);
  return { sites: result.connectedSites || {} };
}

// Handle EIP-1193 requests from dApps
async function handleEthRequest({ method, params }, sender) {
  const origin = new URL(sender.url).origin;
  const state = await getWalletState();

  switch (method) {
    case 'eth_requestAccounts':
    case 'eth_accounts':
      if (!state.isUnlocked) {
        // Open popup to unlock
        await chrome.action.openPopup();
        throw new Error('Wallet is locked');
      }
      const connected = await isSiteConnected(origin);
      if (!connected.connected && method === 'eth_requestAccounts') {
        // Auto-connect for now, could show approval popup
        await connectSite(origin);
      }
      return [state.address];

    case 'eth_chainId':
      const network = await getNetwork();
      return network.chainIdHex;

    case 'net_version':
      const net = await getNetwork();
      return net.chainId.toString();

    case 'eth_getBalance':
      const balanceResult = await getBalance();
      return balanceResult.balance;

    case 'eth_sendTransaction':
      // Create pending request
      const requestId = `tx_${Date.now()}`;
      pendingRequests[requestId] = {
        id: requestId,
        type: 'transaction',
        origin,
        params: params[0],
        timestamp: Date.now()
      };
      
      // Update badge
      updateBadge(Object.keys(pendingRequests).length);
      
      // Open popup for approval
      await chrome.action.openPopup();
      
      // Wait for approval (in real implementation, use Promise that resolves on approval)
      throw new Error('Transaction requires approval');

    case 'personal_sign':
    case 'eth_sign':
      // Similar approval flow for signing
      throw new Error('Signing requires approval');

    case 'wallet_switchEthereumChain':
      const chainId = params[0].chainId;
      const targetNetwork = Object.entries(NETWORKS).find(([_, n]) => n.chainIdHex === chainId);
      if (targetNetwork) {
        await setNetwork(targetNetwork[0]);
        return null;
      }
      throw new Error('Unrecognized chain ID');

    case 'wallet_addEthereumChain':
      // For now, just check if it's a PYRAX chain
      const addChainId = params[0].chainId;
      const existingNetwork = Object.entries(NETWORKS).find(([_, n]) => n.chainIdHex === addChainId);
      if (existingNetwork) {
        return null; // Already exists
      }
      throw new Error('Cannot add custom chains yet');

    default:
      // Forward to RPC
      const networkConfig = await getNetwork();
      return rpcCall(networkConfig.rpcUrl, method, params);
  }
}

// Approve pending transaction
async function approveTransaction(requestId) {
  const request = pendingRequests[requestId];
  if (!request) {
    throw new Error('Request not found');
  }

  const result = await sendTransaction(request.params);
  
  delete pendingRequests[requestId];
  updateBadge(Object.keys(pendingRequests).length);
  
  return result;
}

// Reject pending transaction
async function rejectTransaction(requestId) {
  delete pendingRequests[requestId];
  updateBadge(Object.keys(pendingRequests).length);
  return { success: true };
}

// Broadcast message to all tabs
function broadcastToTabs(message) {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => {
      chrome.tabs.sendMessage(tab.id, message).catch(() => {});
    });
  });
}

// Crypto utilities
async function generateWallet(seedPhrase = null) {
  // Generate or use provided seed phrase
  if (!seedPhrase) {
    seedPhrase = generateSeedPhrase();
  }
  
  // Derive key using BIP39/BIP44
  const seed = await mnemonicToSeed(seedPhrase);
  const { privateKey, address } = deriveEthereumKey(seed);
  
  return { seedPhrase, privateKey, address };
}

function generateSeedPhrase() {
  // BIP39 word list (simplified - in production use full list)
  const wordlist = [
    'abandon', 'ability', 'able', 'about', 'above', 'absent', 'absorb', 'abstract',
    'absurd', 'abuse', 'access', 'accident', 'account', 'accuse', 'achieve', 'acid',
    'acoustic', 'acquire', 'across', 'act', 'action', 'actor', 'actress', 'actual',
    'adapt', 'add', 'addict', 'address', 'adjust', 'admit', 'adult', 'advance',
    'advice', 'aerobic', 'affair', 'afford', 'afraid', 'again', 'age', 'agent',
    'agree', 'ahead', 'aim', 'air', 'airport', 'aisle', 'alarm', 'album',
    'alcohol', 'alert', 'alien', 'all', 'alley', 'allow', 'almost', 'alone',
    'alpha', 'already', 'also', 'alter', 'always', 'amateur', 'amazing', 'among',
    'amount', 'amused', 'analyst', 'anchor', 'ancient', 'anger', 'angle', 'angry',
    'animal', 'ankle', 'announce', 'annual', 'another', 'answer', 'antenna', 'antique',
    'anxiety', 'any', 'apart', 'apology', 'appear', 'apple', 'approve', 'april',
    'arch', 'arctic', 'area', 'arena', 'argue', 'arm', 'armed', 'armor',
    'army', 'around', 'arrange', 'arrest', 'arrive', 'arrow', 'art', 'artefact',
    'artist', 'artwork', 'ask', 'aspect', 'assault', 'asset', 'assist', 'assume',
    'asthma', 'athlete', 'atom', 'attack', 'attend', 'attitude', 'attract', 'auction',
    'audit', 'august', 'aunt', 'author', 'auto', 'autumn', 'average', 'avocado',
    'avoid', 'awake', 'aware', 'away', 'awesome', 'awful', 'awkward', 'axis',
    'baby', 'bachelor', 'bacon', 'badge', 'bag', 'balance', 'balcony', 'ball',
    'bamboo', 'banana', 'banner', 'bar', 'barely', 'bargain', 'barrel', 'base',
    'basic', 'basket', 'battle', 'beach', 'bean', 'beauty', 'because', 'become',
    'beef', 'before', 'begin', 'behave', 'behind', 'believe', 'below', 'belt',
    'bench', 'benefit', 'best', 'betray', 'better', 'between', 'beyond', 'bicycle',
    'bid', 'bike', 'bind', 'biology', 'bird', 'birth', 'bitter', 'black',
    'blade', 'blame', 'blanket', 'blast', 'bleak', 'bless', 'blind', 'blood',
    'blossom', 'blouse', 'blue', 'blur', 'blush', 'board', 'boat', 'body',
    'boil', 'bomb', 'bone', 'bonus', 'book', 'boost', 'border', 'boring',
    'borrow', 'boss', 'bottom', 'bounce', 'box', 'boy', 'bracket', 'brain',
    'brand', 'brass', 'brave', 'bread', 'breeze', 'brick', 'bridge', 'brief',
    'bright', 'bring', 'brisk', 'broccoli', 'broken', 'bronze', 'broom', 'brother',
    'brown', 'brush', 'bubble', 'buddy', 'budget', 'buffalo', 'build', 'bulb',
    'bulk', 'bullet', 'bundle', 'bunker', 'burden', 'burger', 'burst', 'bus',
    'business', 'busy', 'butter', 'buyer', 'buzz', 'cabbage', 'cabin', 'cable'
  ];
  
  const words = [];
  const entropy = new Uint8Array(16);
  crypto.getRandomValues(entropy);
  
  for (let i = 0; i < 12; i++) {
    const index = (entropy[i] + (entropy[(i + 1) % 16] << 8)) % wordlist.length;
    words.push(wordlist[index]);
  }
  
  return words.join(' ');
}

async function mnemonicToSeed(mnemonic) {
  const encoder = new TextEncoder();
  const mnemonicBuffer = encoder.encode(mnemonic.normalize('NFKD'));
  const saltBuffer = encoder.encode('mnemonic');
  
  const keyMaterial = await crypto.subtle.importKey(
    'raw', mnemonicBuffer, 'PBKDF2', false, ['deriveBits']
  );
  
  const seed = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt: saltBuffer, iterations: 2048, hash: 'SHA-512' },
    keyMaterial,
    512
  );
  
  return new Uint8Array(seed);
}

function deriveEthereumKey(seed) {
  // Simplified derivation - in production use proper BIP32/BIP44
  const privateKeyBytes = seed.slice(0, 32);
  const privateKey = '0x' + Array.from(privateKeyBytes).map(b => b.toString(16).padStart(2, '0')).join('');
  
  // Derive address (simplified - hash of public key)
  const addressBytes = new Uint8Array(20);
  for (let i = 0; i < 20; i++) {
    addressBytes[i] = seed[i] ^ seed[i + 20];
  }
  const address = '0x' + Array.from(addressBytes).map(b => b.toString(16).padStart(2, '0')).join('');
  
  return { privateKey, address };
}

async function walletFromPrivateKey(privateKey) {
  if (!privateKey.startsWith('0x')) {
    privateKey = '0x' + privateKey;
  }
  
  // Derive address from private key (simplified)
  const pkBytes = hexToBytes(privateKey.slice(2));
  const addressBytes = new Uint8Array(20);
  for (let i = 0; i < 20; i++) {
    addressBytes[i] = pkBytes[i % 32] ^ pkBytes[(i + 16) % 32];
  }
  const address = '0x' + Array.from(addressBytes).map(b => b.toString(16).padStart(2, '0')).join('');
  
  return { privateKey, address, seedPhrase: null };
}

async function encryptWallet(wallet, password) {
  const encoder = new TextEncoder();
  const data = encoder.encode(JSON.stringify(wallet));
  
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  
  const keyMaterial = await crypto.subtle.importKey(
    'raw', encoder.encode(password), 'PBKDF2', false, ['deriveKey']
  );
  
  const key = await crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt']
  );
  
  const encrypted = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    key,
    data
  );
  
  return {
    encrypted: bytesToBase64(new Uint8Array(encrypted)),
    salt: bytesToBase64(salt),
    iv: bytesToBase64(iv)
  };
}

async function decryptWallet(encryptedWallet, password) {
  const encoder = new TextEncoder();
  const decoder = new TextDecoder();
  
  const encrypted = base64ToBytes(encryptedWallet.encrypted);
  const salt = base64ToBytes(encryptedWallet.salt);
  const iv = base64ToBytes(encryptedWallet.iv);
  
  const keyMaterial = await crypto.subtle.importKey(
    'raw', encoder.encode(password), 'PBKDF2', false, ['deriveKey']
  );
  
  const key = await crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['decrypt']
  );
  
  const decrypted = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv },
    key,
    encrypted
  );
  
  return JSON.parse(decoder.decode(decrypted));
}

async function signTransaction(tx, privateKey) {
  // Simplified signing - in production use proper ECDSA
  const txData = JSON.stringify(tx);
  const encoder = new TextEncoder();
  const data = encoder.encode(txData);
  
  const signature = await crypto.subtle.digest('SHA-256', data);
  return '0x' + bytesToHex(new Uint8Array(signature)) + bytesToHex(hexToBytes(privateKey.slice(2, 66)));
}

async function signMessage(message, privateKey) {
  const encoder = new TextEncoder();
  const prefix = `\x19Ethereum Signed Message:\n${message.length}`;
  const data = encoder.encode(prefix + message);
  
  const hash = await crypto.subtle.digest('SHA-256', data);
  return '0x' + bytesToHex(new Uint8Array(hash));
}

// RPC helper
async function rpcCall(url, method, params = []) {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      jsonrpc: '2.0',
      id: Date.now(),
      method,
      params
    })
  });
  
  const data = await response.json();
  if (data.error) {
    throw new Error(data.error.message || 'RPC error');
  }
  return data.result;
}

// Utility functions
function formatBalance(hexBalance) {
  const wei = BigInt(hexBalance || '0x0');
  const pyrax = Number(wei) / 1e18;
  return pyrax.toFixed(4);
}

function hexToBytes(hex) {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = parseInt(hex.substr(i * 2, 2), 16);
  }
  return bytes;
}

function bytesToHex(bytes) {
  return Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('');
}

function bytesToBase64(bytes) {
  return btoa(String.fromCharCode(...bytes));
}

function base64ToBytes(base64) {
  return new Uint8Array(atob(base64).split('').map(c => c.charCodeAt(0)));
}

// Auto-lock after inactivity
let lockTimer;
function resetLockTimer() {
  clearTimeout(lockTimer);
  lockTimer = setTimeout(async () => {
    await lockWallet();
  }, 15 * 60 * 1000); // 15 minutes
}

chrome.storage.onChanged.addListener((changes) => {
  if (changes.isUnlocked?.newValue) {
    resetLockTimer();
  }
});

console.log('PYRAX Wallet service worker initialized');
